﻿require(["jquery", "crossroads", "hasher", "knockout"], function ($, crossroads, hasher, ko) {

    $(document).ready(function () {

        var pageViewModel = {
            currentPage: ko.observable()
        };

        var registeredComponents = new Array();

        function registerComponent(name) {
            if (registeredComponents.indexOf(name) == -1) {
                registeredComponents.push(name);
                ko.components.register(name, {
                    viewModel: { require: 'App/Views/' + name + 'ViewModel' },
                    template: { require: 'text!App/Views/' + name + 'View.html' }
                });
            }
        }

        function handleRoute(hash) {
            registerComponent(hash);
            pageViewModel.currentPage(hash);
        }

        function parseHash(newHash, oldHash) {
            crossroads.parse(newHash);
        }

        crossroads.addRoute("{page}", handleRoute, 0);

        hasher.initialized.add(parseHash); //parse initial hash
        hasher.changed.add(parseHash); //parse hash changes
        hasher.init(); //start listening for history change

        var hash = hasher.getHash();
        if (hash == '')
            hasher.setHash('');
        else {
            handleRoute(hash);
        }

        ko.applyBindings(pageViewModel);

    });
});