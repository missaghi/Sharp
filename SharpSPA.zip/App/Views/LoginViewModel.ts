﻿import ko = require('knockout');
import toastr = require('toastr');
import moment = require('moment');
import hasher = require('hasher');
import Database = require('../Models/Database');

class LoginViewModel {

    adminUserModel: Database.AdminUserModel;
     
    email : KnockoutObservable<string> = ko.observable(null);
    password: KnockoutObservable<string> = ko.observable(null);
    rememberMe: KnockoutObservable<boolean> = ko.observable(null); 

    Login = () => {
        $.ajax("./api/login", { 
            method: "POST",
            dataType: "json",
            data: { Email: this.email(), Password: this.password(), RememberMe: this.rememberMe() },
            success: (json) => {
                toastr.success(JSON.stringify(json));
                this.adminUserModel = new Database.AdminUserModel(json.data);
                this.GetUserId();
            },
            error: (json) => {
            }
        });
    }; 

    GetUserId = () => {
        $.ajax("./api/user/id", {
            dataType: "json",
            success: (json) => {
                toastr.success(json.data);
            },
            error: (json) => {
            }
        });
    }; 

    constructor(params: any) {
        //this.adminUserModel = new Database.AdminUserModel();
    }
}
export = LoginViewModel;