
import ko = require('knockout');   
module Database {


    export class AdminUserModel { 
        
        public UserId: KnockoutObservable<number> = ko.observable(0);
        public Email: KnockoutObservable<string> = ko.observable(null);
        public Password: KnockoutObservable<string> = ko.observable(null);
        public InsertDate: KnockoutObservable<Date> = ko.observable(null);

        constructor(data: any = null) {

            if (data !== null) { 
                if (data.UserId != null){
                this.UserId(ko.unwrap(data.UserId));}
                if (data.Email != null){
                this.Email(ko.unwrap(data.Email));}
                if (data.Password != null){
                this.Password(ko.unwrap(data.Password));}
                if (data.InsertDate != null){
                this.InsertDate(ko.unwrap(new Date(data.InsertDate)));}
            }
        }
    }
} export = Database;