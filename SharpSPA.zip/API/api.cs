﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using Sharp;
using Sharp.EndPoints;

namespace $safeprojectname$.API
{

    public class API : EndpointHandler
    {
        [EndPointPlugin("api/login")]
        public ConnStr.AdminUserModel Login(string email, string password, bool rememberMe)
        {

            var user = ConnStr.AdminUserModel.SingleOrDefault("where email like @0", email);

            if (user == null)
            {
                sb.ErrorMsg = "User not found";
            }
            else
            {
                FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(email, rememberMe, 24 * 60);
                string encryptedTicket = FormsAuthentication.Encrypt(ticket);
                HttpCookie cookie = new HttpCookie(FormsAuthentication.FormsCookieName, encryptedTicket);
                cookie.HttpOnly = true;
                context.Response.Cookies.Add(cookie); 
            }

            return user;

        }

        [Secure]
        [EndPointPlugin("api/user/id")]
        public string GetCurrentUserBase31Id()
        {
            var user = ConnStr.AdminUserModel.SingleOrDefault("where email like @0", context.User.Identity.Name);
            var userBase31ID = new Sharp.rBase31(user.UserId);
            return userBase31ID.Value;
        }

    }


}