﻿require.config({
    baseUrl: "",
    paths: {
        "jquery": "Scripts/jquery-3.1.0.min",
        "knockout": "Scripts/knockout-3.4.0",
        "knockout.mapping": "Scripts/knockout.mapping-latest",
        "moment": "Scripts/moment.min",
        "text": "Scripts/text",
        "hasher": "Scripts/hasher",
        "signals": "Scripts/signals",
        "toastr": "Scripts/toastr.min",
        "knockout.validation": "Scripts/knockout.validation.min",
        "crossroads": "Scripts/crossroads",
        bootstrap: 'Scripts/bootstrap.min'
    },
    shim: {
        "jquery": {
            exports: "$"
        },
        hasher: { dep: ['signals'] },
        "knockout.validation": { dep: ['knockout'] },
        crossroads: { dep: ['hasher'] },
        bootstrap: { exports: 'bootstrap', dep: ['jquery'] },
        moment: { exports: 'moment' },
    }
});
require(["app/main"]);